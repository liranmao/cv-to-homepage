# 背景素材包 / Background library

打开 index.html 预览。修改 body 的 data-background 选择效果：
particles, paper, dots, grid, aurora, stars, contours, spotlight, mesh, lines, none。

将 assets/ 复制到你的网站，并保留示例中的样式表、脚本和两个背景容器。用 --accent 设置背景主色。深色星野可配 #111b29 底色和 #9dc2e5 强调色。

Open index.html. Set body[data-background] to one of the IDs above. Copy assets/ and the example's stylesheet, scripts, and background containers into your site. Use --accent for the effect color. A dark starfield can use #111b29 for the page and #9dc2e5 for the accent.

素材参数和参考链接见 designs.json。particles.js 使用 MIT 许可，其余素材使用 CC0。许可全文随包提供。
Parameters and references are in designs.json. particles.js is MIT licensed; the other effects are CC0. Full licenses are included.
